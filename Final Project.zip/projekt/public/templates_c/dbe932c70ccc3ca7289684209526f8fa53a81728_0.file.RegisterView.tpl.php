<?php
/* Smarty version 3.1.34-dev-7, created on 2021-06-23 20:08:10
  from 'E:\xxamp\htdocs\projekt\app\views\RegisterView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60d3788a10b321_95689205',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dbe932c70ccc3ca7289684209526f8fa53a81728' => 
    array (
      0 => 'E:\\xxamp\\htdocs\\projekt\\app\\views\\RegisterView.tpl',
      1 => 1624471688,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60d3788a10b321_95689205 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_56877604060d3788a106dd2_26458728', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'content'} */
class Block_56877604060d3788a106dd2_26458728 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_56877604060d3788a106dd2_26458728',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
register" method="post" class="pure-form pure-form-aligned bottom-margin">
	<legend>Zarejestruj się</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="login">login: </label>
			<input id="login" type="text" name="login"/>
		</div>
        <div class="pure-control-group">
			<label for="pass">pass: </label>
			<input id="pass" type="password" name="pass" /><br />
		</div>
         <div class="pure-control-group">
			<label for="name">Imie: </label>
			<input id="name" type="text" name="name"/>
		</div>
        <div class="pure-control-group">
			<label for="surname">Nazwisko: </label>
			<input id="surname" type="text" name="surname" /><br />
		</div>
         <div class="pure-control-group">
			<label for="pesel">Pesel: </label>
			<input id="pesel" type="text" name="pesel"/>
		</div>
		<div class="pure-controls">
            
            

			<input type="submit" value="Zarejestuj sie" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	


	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logout" class="pure-menu-heading pure-menu-link">Powrót</a> 

 

<?php
}
}
/* {/block 'content'} */
}
