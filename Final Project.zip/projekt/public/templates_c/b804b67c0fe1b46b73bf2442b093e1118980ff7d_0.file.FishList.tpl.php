<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-03 11:45:36
  from 'C:\xampp\htdocs\projekt\app\views\FishList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60e031c0602c09_18538951',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b804b67c0fe1b46b73bf2442b093e1118980ff7d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\FishList.tpl',
      1 => 1625305206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60e031c0602c09_18538951 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_31398899760e031c05b5543_17941001', 'top');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_208627190760e031c05c9166_06079275', 'bottom');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'top'} */
class Block_31398899760e031c05b5543_17941001 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_31398899760e031c05b5543_17941001',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishList">
	<legend>Opcje wyszukiwania</legend>
	<fieldset>
		<input type="text" placeholder="Nazwa ryby" name="fishname" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->fishname;?>
" /><br />
		<button type="submit" class="pure-button pure-button-primary">Filtruj</button>
	</fieldset>
</form>
</div>	

<?php
}
}
/* {/block 'top'} */
/* {block 'bottom'} */
class Block_208627190760e031c05c9166_06079275 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'bottom' => 
  array (
    0 => 'Block_208627190760e031c05c9166_06079275',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


 <p >Witaj użytkowniku <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </p>
  Twój status <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>

<br><br>
 <?php if ($_smarty_tpl->tpl_vars['user']->value) {?>
        <?php if ($_smarty_tpl->tpl_vars['user']->value->role == "admin") {?>
        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
AdminPanelGo" class="pure-menu-heading pure-menu-link">Panel administratora</a>
        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishNew" class="pure-menu-heading pure-menu-link">Dodaj Rybke</a>
        <?php }?>
 <?php }?>
	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logout" class="pure-menu-heading pure-menu-link">Wyloguj</a>
 

<?php if ($_smarty_tpl->tpl_vars['user']->value) {?>
        
        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
Equipment" class="pure-menu-heading pure-menu-link">Wynajmnij sprzęt na dzisiaj</a>
        
 <?php }?>

<table id="tab_people" class="pure-table pure-table-bordered">
<thead>
	<tr>
		<th>Nazwa Ryby</th>
		<th>nr Stawu</th>
		<th>cena za kg</th>
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['ryby']->value, 'p');
$_smarty_tpl->tpl_vars['p']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['p']->value["Nazwa_ryby"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["nr_stawu"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["cena_za_kilogram"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "admin") {?><td><a class="button-small pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishEdit/<?php echo $_smarty_tpl->tpl_vars['p']->value['ID_Ryby'];?>
">Edytuj</a>&nbsp;<a onclick="confirmLink('<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishDelete/<?php echo $_smarty_tpl->tpl_vars['p']->value['ID_Ryby'];?>
','Czy na pewno usunąć Rybe?')" class="button-small pure-button button-warning">Usuń</a></td><?php }?></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</tbody>
</table>
<div class="kontent2" >
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishList/<?php echo $_smarty_tpl->tpl_vars['page']->value->page-$_smarty_tpl->tpl_vars['page']->value->total;?>
" class="pure-button pure-button-primary">Początek</a>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishList/<?php echo $_smarty_tpl->tpl_vars['page']->value->page-1;?>
" class="pure-button pure-button-primary"><</a>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishList/<?php echo $_smarty_tpl->tpl_vars['page']->value->page+1;?>
" class="pure-button pure-button-primary">></a>
<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
FishList/<?php echo $_smarty_tpl->tpl_vars['page']->value->page+$_smarty_tpl->tpl_vars['page']->value->total;?>
" class="pure-button pure-button-primary">Koniec</a>
</div>
<?php
}
}
/* {/block 'bottom'} */
}
