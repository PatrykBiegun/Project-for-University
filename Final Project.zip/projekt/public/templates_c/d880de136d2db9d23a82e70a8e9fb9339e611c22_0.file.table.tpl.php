<?php
/* Smarty version 3.1.34-dev-7, created on 2021-06-29 13:44:43
  from 'E:\xxamp\htdocs\projekt\app\views\table.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60db07ab2eeca2_38873683',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd880de136d2db9d23a82e70a8e9fb9339e611c22' => 
    array (
      0 => 'E:\\xxamp\\htdocs\\projekt\\app\\views\\table.tpl',
      1 => 1624967080,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60db07ab2eeca2_38873683 (Smarty_Internal_Template $_smarty_tpl) {
?><table id="tab_people" class="pure-table pure-table-bordered">
<thead>
	<tr>
        <th> id_sprzetu</th>
		<th> Nazwa Sprzetu</th>
		<th> Cena </th>
		<th> Rodzaj </th>
        <th> Opis </th>
	</tr>
</thead>
<tbody>
    Twoje rzeczy:
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sprzet']->value, 'p');
$_smarty_tpl->tpl_vars['p']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->do_else = false;
?>
    <?php if ($_smarty_tpl->tpl_vars['p']->value["uzytkownicy_ID"] == $_smarty_tpl->tpl_vars['user']->value->id) {?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['p']->value["id_sprzetu"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["morenka"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "staly") {?><td><?php echo $_smarty_tpl->tpl_vars['p']->value["cena"]-$_smarty_tpl->tpl_vars['p']->value["cena"]*0.20;?>
</td><?php }
if ($_smarty_tpl->tpl_vars['user']->value->role == "uzytkownik") {?><td><?php echo $_smarty_tpl->tpl_vars['p']->value["cena"];?>
</td><?php }?><td><?php echo $_smarty_tpl->tpl_vars['p']->value["nazwa"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["opis"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "staly") {?><td><a onclick="confirmLink('<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
EquipmentBack/<?php echo $_smarty_tpl->tpl_vars['p']->value['id_sprzetu'];?>
/<?php echo $_smarty_tpl->tpl_vars['p']->value['cena'];?>
','Czy na pewno chcesz anulować? Zostaniesz obciążony dodatkowymi kosztami wysokości 10% ')" class="button-small pure-button button-secondary">Nie Wynajmuj</a>&nbsp;</td><?php }
if ($_smarty_tpl->tpl_vars['user']->value->role == "uzytkownik") {?><td><a onclick="confirmLink('<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
EquipmentBack/<?php echo $_smarty_tpl->tpl_vars['p']->value['id_sprzetu'];?>
/<?php echo $_smarty_tpl->tpl_vars['p']->value['cena']+$_smarty_tpl->tpl_vars['p']->value['cena']*0.10;?>
','Czy na pewno chcesz wynająć? Masz 24h na oddanie sprzętu')" class="button-small pure-button button-secondary">Nie Wynajmuj</a>&nbsp;</td><?php }?></tr>

    <?php }?>
           

<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
   
    
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sprzet']->value, 'p');
$_smarty_tpl->tpl_vars['p']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->do_else = false;
?>
    <?php if ($_smarty_tpl->tpl_vars['p']->value["uzytkownicy_ID"] == NULL) {?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['p']->value["id_sprzetu"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["morenka"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "staly") {?><td><?php echo $_smarty_tpl->tpl_vars['p']->value["cena"]-$_smarty_tpl->tpl_vars['p']->value["cena"]*0.20;?>
</td><?php }
if ($_smarty_tpl->tpl_vars['user']->value->role == "uzytkownik") {?><td><?php echo $_smarty_tpl->tpl_vars['p']->value["cena"];?>
</td><?php }?><td><?php echo $_smarty_tpl->tpl_vars['p']->value["nazwa"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["opis"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "staly" || $_smarty_tpl->tpl_vars['user']->value->role == "admin") {?><td><a onclick="confirmLink('<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
EquipmentRent/<?php echo $_smarty_tpl->tpl_vars['p']->value['id_sprzetu'];?>
/<?php echo $_smarty_tpl->tpl_vars['p']->value['cena']-$_smarty_tpl->tpl_vars['p']->value['cena']*0.10;?>
','Czy na pewno chcesz wynająć? Masz 24h na oddanie sprzętu')" class="button-small pure-button button-secondary">Wynajmij</a>&nbsp;</td><?php }
if ($_smarty_tpl->tpl_vars['user']->value->role == "uzytkownik") {?><td><a onclick="confirmLink('<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
EquipmentRent/<?php echo $_smarty_tpl->tpl_vars['p']->value['id_sprzetu'];?>
/<?php echo $_smarty_tpl->tpl_vars['p']->value['cena'];?>
','Czy na pewno chcesz wynająć? Masz 24h na oddanie sprzętu')" class="button-small pure-button button-secondary">Wynajmij</a>&nbsp;</td><?php }?></tr>
    <?php }
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    
    
    
    
    
</tbody>
</table><?php }
}
