<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-12 15:44:09
  from 'C:\xampp\htdocs\projekt\app\views\FishEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60ec4729d6f915_16379159',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5995913a8f46e30f298016558fcd358d9ea8c12f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\FishEdit.tpl',
      1 => 1625305206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60ec4729d6f915_16379159 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_202681265660ec4729d64012_36241144', 'top');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'top'} */
class Block_202681265660ec4729d64012_36241144 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_202681265660ec4729d64012_36241144',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishSave" method="post" class="pure-form pure-form-aligned">
	<fieldset>
		<legend>Dane osoby</legend>
		<div class="pure-control-group">
            <label for="name">Nazwa Ryby</label>
            <input id="name" type="text" placeholder="nazwa ryby" name="Nazwa_ryby" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->Nazwa_ryby;?>
">
        </div>
		<div class="pure-control-group">
            <label for="surname">numer stawu</label>
            <select name="nr_stawu" id="nr_stawu">        
  <option value="1">1</option>             
  <option value="2">2</option>        
           </select>
        </div>
		<div class="pure-control-group">
            <label for="birthdate">cena za kilogram</label>
            <input id="birthdate" type="text" placeholder="cena za kg" name="cena_za_kilogram" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->cena_za_kilogram;?>
">
        </div>
		<div class="pure-controls">
			<input type="submit" class="pure-menu-heading pure-menu-link" value="Zapisz Ustawienia"/>
			<a class="pure-menu-heading pure-menu-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishList">Powrót</a>
		</div>
	</fieldset>
    <input type="hidden" name="ID_Ryby" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->ID_Ryby;?>
">
</form>	
</div>

<?php
}
}
/* {/block 'top'} */
}
