<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-12 15:39:02
  from 'C:\xampp\htdocs\projekt\app\views\RegisterView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60ec45f6beca03_92859083',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8cdc25903611454832eca4772752d1ab8ae5f9e7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\RegisterView.tpl',
      1 => 1625305207,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60ec45f6beca03_92859083 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5044714960ec45f6b604a0_31855383', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'content'} */
class Block_5044714960ec45f6b604a0_31855383 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_5044714960ec45f6b604a0_31855383',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
register" method="post" class="pure-form pure-form-aligned bottom-margin">
	<legend>Zarejestruj się</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="login">login: </label>
			<input id="login" type="text" name="login"/>
		</div>
        <div class="pure-control-group">
			<label for="pass">pass: </label>
			<input id="pass" type="password" name="pass" /><br />
		</div>
         <div class="pure-control-group">
			<label for="name">Imie: </label>
			<input id="name" type="text" name="name"/>
		</div>
        <div class="pure-control-group">
			<label for="surname">Nazwisko: </label>
			<input id="surname" type="text" name="surname" /><br />
		</div>
         <div class="pure-control-group">
			<label for="pesel">Pesel: </label>
			<input id="pesel" type="text" name="pesel"/>
		</div>
		<div class="pure-controls">
            
            

			<input type="submit" value="Zarejestuj sie" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	


	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logout" class="pure-menu-heading pure-menu-link">Powrót</a> 

 

<?php
}
}
/* {/block 'content'} */
}
