<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-03 11:45:08
  from 'C:\xampp\htdocs\projekt\app\views\LoginView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60e031a4d0bd86_04235041',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '633b3a273d02be29d1a43866a0f5cb5a2b010b46' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\LoginView.tpl',
      1 => 1625305206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60e031a4d0bd86_04235041 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_30025109460e031a4cfa7c2_14518746', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'content'} */
class Block_30025109460e031a4cfa7c2_14518746 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_30025109460e031a4cfa7c2_14518746',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
login" method="post" class="pure-form pure-form-aligned bottom-margin">
	<legend>Logowanie do systemu</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="login">login: </label>
			<input id="login" type="text" name="login"/>
		</div>
        <div class="pure-control-group">
			<label for="pass">pass: </label>
			<input id="pass" type="password" name="pass" /><br />
		</div>
		<div class="pure-controls">
			<input type="submit" value="zaloguj" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	



  <a href = "<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
register"  class="pure-menu-heading pure-menu-link"> Rejestracja</a>    




<?php
}
}
/* {/block 'content'} */
}
