<?php
/* Smarty version 3.1.34-dev-7, created on 2021-06-23 20:32:52
  from 'E:\xxamp\htdocs\projekt\app\views\EquipmentView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60d37e54ce0450_23126661',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ecc6a7ba84b4d6a9b229aba7902466ab64a54ae7' => 
    array (
      0 => 'E:\\xxamp\\htdocs\\projekt\\app\\views\\EquipmentView.tpl',
      1 => 1624471812,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:table.tpl' => 1,
  ),
),false)) {
function content_60d37e54ce0450_23126661 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4884376860d37e54cd7521_53063840', 'userlist');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'userlist'} */
class Block_4884376860d37e54cd7521_53063840 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'userlist' => 
  array (
    0 => 'Block_4884376860d37e54cd7521_53063840',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


 <p>Witaj użytkowniku <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </p>
  Twój status <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>

<br><br>
 
<div class="bottom-margin">
<form class="pure-form pure-form-stacked" id = "search" method = "post" onsubmit="ajaxPostForm('search','<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
EquipmentSorted','1'); return false;">

	<legend>Opcje wyszukiwania</legend>
	<fieldset>
		 <select name="nazwa" id="nazwa">
             
  <option value="">wszystko</option>             
  <option value="wędka">wędka</option>
  <option value="łódka">łódka</option>
  <option value="wiadro">wiadro</option>
  <option value="zanęta">zanęta</option>
  <option value="krzesło">krzesło</option>
             
           
           </select>
		<button type="submit" class="pure-menu-heading pure-menu-link">Filtruj</button>
	</fieldset>
</form>
    
</div>	
 
   <legend>Suma pieniędzy jaką wydałeś:</legend>  <?php echo $_smarty_tpl->tpl_vars['suma']->value;?>


	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logout" class="pure-menu-heading pure-menu-link">Wyloguj</a>
 
    <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishList" class="pure-menu-heading pure-menu-link">Wróć na poprzednią stronę</a>   

   
     



<div id='1'> 
<?php $_smarty_tpl->_subTemplateRender("file:table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</div>





<?php
}
}
/* {/block 'userlist'} */
}
