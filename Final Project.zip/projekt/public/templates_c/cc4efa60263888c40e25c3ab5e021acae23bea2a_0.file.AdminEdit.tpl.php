<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-12 15:45:11
  from 'C:\xampp\htdocs\projekt\app\views\AdminEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60ec4767ca9b22_88134235',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cc4efa60263888c40e25c3ab5e021acae23bea2a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\AdminEdit.tpl',
      1 => 1625305206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60ec4767ca9b22_88134235 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_151241498560ec4767ca2871_01334891', 'top');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'top'} */
class Block_151241498560ec4767ca2871_01334891 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_151241498560ec4767ca2871_01334891',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
UserSave" method="post" class="pure-form pure-form-aligned">
	<fieldset>
		<legend>Dane osoby</legend>
		<div class="pure-control-group">
            <label for="imie">imie</label>
            <input id="imie" type="text" placeholder="imie" name="imie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->imie;?>
">
        </div>
		<div class="pure-control-group">
            <label for="nazwisko">nazwisko</label>
            <input id="nazwisko" type="text" placeholder="nazwisko" name="nazwisko" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwisko;?>
">
        </div>
		<div class="pure-control-group">
            <label for="login">login</label>
            <input id="login" type="text" placeholder="login" name="login" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->login;?>
">
        </div>
        <div class="pure-control-group">
            <label for="idroli">Rola </label>
            
           <select name="idroli" id="idroli">
               
  <option value="1">admin</option>
  <option value="2">użytkownik</option>
  <option value="3">stały użytkownik</option>
           
           </select>
            
        </div>
        
		<div class="pure-controls">
			<input type="submit" class="pure-button pure-button-primary" value="Zapisz Ustawienia"/>
			<a class="pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
AdminPanelGo">Powrót</a>
		</div>
	</fieldset>
    <input type="hidden" name="ID" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->ID;?>
">
</form>	
</div>

<?php
}
}
/* {/block 'top'} */
}
