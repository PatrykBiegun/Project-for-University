<?php
/* Smarty version 3.1.34-dev-7, created on 2021-06-23 20:18:31
  from 'E:\xxamp\htdocs\projekt\app\views\AdminView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60d37af7d9ea11_84010997',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7381a476051f83fb0894d9f8e9409d596e80be09' => 
    array (
      0 => 'E:\\xxamp\\htdocs\\projekt\\app\\views\\AdminView.tpl',
      1 => 1624472309,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60d37af7d9ea11_84010997 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_143358431060d37af7d89f20_24833909', 'userlist');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'userlist'} */
class Block_143358431060d37af7d89f20_24833909 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'userlist' => 
  array (
    0 => 'Block_143358431060d37af7d89f20_24833909',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


 <p >witaj użytkowniku <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </p>
  Twój status <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>

<br><br>

	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logout" class="pure-menu-heading pure-menu-link">Wyloguj</a>
 
    <a class="pure-menu-heading pure-menu-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishList">Powrót</a>


<table id="tab_people" class="pure-table pure-table-bordered">
<thead>
	<tr>
        <th>ID</th>
		<th>login</th>
		<th>Imie </th>
		<th>Nazwisko </th>
        <th>pesel </th>
		<th> data Modyfiakcji </th>
        <th> kto modyfikował </th>
        <th> Nazwa Roli </th>
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['uzytkownicy']->value, 'p');
$_smarty_tpl->tpl_vars['p']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['p']->value["ID"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["login"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["imie"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["nazwisko"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["pesel"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["data_Modyfiakcji"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["kto_modyfikowal"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["Nazwa_Roli"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "admin") {?><td><a class="button-small pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
UserEdit/<?php echo $_smarty_tpl->tpl_vars['p']->value['ID'];?>
">Edytuj</a>&nbsp;<a class="button-small pure-button button-warning" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
UserDelete/<?php echo $_smarty_tpl->tpl_vars['p']->value['ID'];?>
">Usuń</a></td><?php }?></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    <thead>
	<tr>
        <th> id_sprzetu</th>
		<th> Nazwa Sprzetu</th>
		<th> Cena </th>
		<th> Rodzaj </th>
        <th> Kto Wynajmuje</th>
	</tr>
</thead>
</tbody>
</table>

<table id="tab_eq" class="pure-table pure-table-bordered">

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sprzet']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
    <?php if ($_smarty_tpl->tpl_vars['r']->value["uzytkownicy_ID"] > 0) {?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['r']->value["id_sprzetu"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["morenka"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "staly") {?><td><?php echo $_smarty_tpl->tpl_vars['r']->value["cena"]-$_smarty_tpl->tpl_vars['p']->value["cena"]*0.20;?>
</td><?php }
if ($_smarty_tpl->tpl_vars['user']->value->role == "uzytkownik") {?><td><?php echo $_smarty_tpl->tpl_vars['r']->value["cena"];?>
</td><?php }?><td><?php echo $_smarty_tpl->tpl_vars['r']->value["nazwa"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["uzytkownicy_ID"];?>
</td><td><a onclick="confirmLink('<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
AdminRemove/<?php echo $_smarty_tpl->tpl_vars['r']->value['id_sprzetu'];?>
/<?php echo $_smarty_tpl->tpl_vars['r']->value['cena']-$_smarty_tpl->tpl_vars['r']->value['cena']*0.20;?>
','Czy na pewno ten klient zwrócił? Po oddaniu nie będzie możliwości zmiany')" class="button-small pure-button button-secondary">Klient wzrócił</a>&nbsp;</td></tr>
    <?php }
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</table>
<?php
}
}
/* {/block 'userlist'} */
}
