<?php
/* Smarty version 3.1.34-dev-7, created on 2021-06-29 12:44:12
  from 'E:\xxamp\htdocs\projekt\app\views\FishEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60daf97cccd8d3_91112663',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '71a5cc9810702367ec3a0f15e52d5f0eeee1c769' => 
    array (
      0 => 'E:\\xxamp\\htdocs\\projekt\\app\\views\\FishEdit.tpl',
      1 => 1624963450,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60daf97cccd8d3_91112663 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_45268927860daf97ccc8d24_51584182', 'top');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'top'} */
class Block_45268927860daf97ccc8d24_51584182 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_45268927860daf97ccc8d24_51584182',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishSave" method="post" class="pure-form pure-form-aligned">
	<fieldset>
		<legend>Dane osoby</legend>
		<div class="pure-control-group">
            <label for="name">Nazwa Ryby</label>
            <input id="name" type="text" placeholder="nazwa ryby" name="Nazwa_ryby" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->Nazwa_ryby;?>
">
        </div>
		<div class="pure-control-group">
            <label for="surname">numer stawu</label>
            <select name="nr_stawu" id="nr_stawu">        
  <option value="1">1</option>             
  <option value="2">2</option>        
           </select>
        </div>
		<div class="pure-control-group">
            <label for="birthdate">cena za kilogram</label>
            <input id="birthdate" type="text" placeholder="cena za kg" name="cena_za_kilogram" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->cena_za_kilogram;?>
">
        </div>
		<div class="pure-controls">
			<input type="submit" class="pure-menu-heading pure-menu-link" value="Zapisz Ustawienia"/>
			<a class="pure-menu-heading pure-menu-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishList">Powrót</a>
		</div>
	</fieldset>
    <input type="hidden" name="ID_Ryby" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->ID_Ryby;?>
">
</form>	
</div>

<?php
}
}
/* {/block 'top'} */
}
