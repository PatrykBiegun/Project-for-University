<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-03 11:45:42
  from 'C:\xampp\htdocs\projekt\app\views\EquipmentView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60e031c6627c56_86831208',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d48008214a8984d98a5ab4741aead0bb705ee4d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\EquipmentView.tpl',
      1 => 1625305206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:table.tpl' => 1,
  ),
),false)) {
function content_60e031c6627c56_86831208 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_87640967360e031c6611328_00158938', 'userlist');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'userlist'} */
class Block_87640967360e031c6611328_00158938 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'userlist' => 
  array (
    0 => 'Block_87640967360e031c6611328_00158938',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


 <p>Witaj użytkowniku <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </p>
  Twój status <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>

<br><br>
 
<div class="bottom-margin">
<form class="pure-form pure-form-stacked" id = "search" method = "post" onsubmit="ajaxPostForm('search','<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
EquipmentSorted','1'); return false;">

	<legend>Opcje wyszukiwania</legend>
	<fieldset>
		 <select name="nazwa" id="nazwa">
             
  <option value="">wszystko</option>             
  <option value="wędka">wędka</option>
  <option value="łódka">łódka</option>
  <option value="wiadro">wiadro</option>
  <option value="zanęta">zanęta</option>
  <option value="krzesło">krzesło</option>
             
           
           </select>
		<button type="submit" class="pure-menu-heading pure-menu-link">Filtruj</button>
	</fieldset>
</form>
    
</div>	
 
   <legend>Suma pieniędzy jaką wydałeś:</legend>  <?php echo $_smarty_tpl->tpl_vars['suma']->value;?>


	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logout" class="pure-menu-heading pure-menu-link">Wyloguj</a>
 
    <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishList" class="pure-menu-heading pure-menu-link">Wróć na poprzednią stronę</a>   

   
     



<div id='1'> 
<?php $_smarty_tpl->_subTemplateRender("file:table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</div>





<?php
}
}
/* {/block 'userlist'} */
}
