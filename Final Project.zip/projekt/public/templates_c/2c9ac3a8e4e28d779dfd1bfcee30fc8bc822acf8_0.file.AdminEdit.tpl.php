<?php
/* Smarty version 3.1.34-dev-7, created on 2021-06-23 18:00:42
  from 'E:\xxamp\htdocs\projekt\app\views\AdminEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60d35aaaa57935_01866465',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2c9ac3a8e4e28d779dfd1bfcee30fc8bc822acf8' => 
    array (
      0 => 'E:\\xxamp\\htdocs\\projekt\\app\\views\\AdminEdit.tpl',
      1 => 1624463955,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60d35aaaa57935_01866465 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_97576338860d35aaaa53b21_74122475', 'top');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'top'} */
class Block_97576338860d35aaaa53b21_74122475 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_97576338860d35aaaa53b21_74122475',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="bottom-margin">
<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
UserSave" method="post" class="pure-form pure-form-aligned">
	<fieldset>
		<legend>Dane osoby</legend>
		<div class="pure-control-group">
            <label for="imie">imie</label>
            <input id="imie" type="text" placeholder="imie" name="imie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->imie;?>
">
        </div>
		<div class="pure-control-group">
            <label for="nazwisko">nazwisko</label>
            <input id="nazwisko" type="text" placeholder="nazwisko" name="nazwisko" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwisko;?>
">
        </div>
		<div class="pure-control-group">
            <label for="login">login</label>
            <input id="login" type="text" placeholder="login" name="login" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->login;?>
">
        </div>
        <div class="pure-control-group">
            <label for="idroli">Rola </label>
            
           <select name="idroli" id="idroli">
               
  <option value="1">admin</option>
  <option value="2">użytkownik</option>
  <option value="3">stały użytkownik</option>
           
           </select>
            
        </div>
        
		<div class="pure-controls">
			<input type="submit" class="pure-button pure-button-primary" value="Zapisz Ustawienia"/>
			<a class="pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
AdminPanelGo">Powrót</a>
		</div>
	</fieldset>
    <input type="hidden" name="ID" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->ID;?>
">
</form>	
</div>

<?php
}
}
/* {/block 'top'} */
}
