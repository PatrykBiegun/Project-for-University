<?php
/* Smarty version 3.1.34-dev-7, created on 2021-06-23 20:07:45
  from 'E:\xxamp\htdocs\projekt\app\views\LoginView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60d3787110f760_54566150',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eee405dd0c1cee853ebca61cb31e4cfb65b4890a' => 
    array (
      0 => 'E:\\xxamp\\htdocs\\projekt\\app\\views\\LoginView.tpl',
      1 => 1624471384,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60d3787110f760_54566150 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_155403791260d3787110be31_89494174', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'content'} */
class Block_155403791260d3787110be31_89494174 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_155403791260d3787110be31_89494174',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
login" method="post" class="pure-form pure-form-aligned bottom-margin">
	<legend>Logowanie do systemu</legend>
	<fieldset>
        <div class="pure-control-group">
			<label for="login">login: </label>
			<input id="login" type="text" name="login"/>
		</div>
        <div class="pure-control-group">
			<label for="pass">pass: </label>
			<input id="pass" type="password" name="pass" /><br />
		</div>
		<div class="pure-controls">
			<input type="submit" value="zaloguj" class="pure-button pure-button-primary"/>
		</div>
	</fieldset>
</form>	



  <a href = "<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
register"  class="pure-menu-heading pure-menu-link"> Rejestracja</a>    




<?php
}
}
/* {/block 'content'} */
}
