<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-03 11:45:39
  from 'C:\xampp\htdocs\projekt\app\views\AdminView.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60e031c3284aa3_73948886',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '35344f25211a5889163d769d69c2b6dcd14d6143' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\AdminView.tpl',
      1 => 1625305206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60e031c3284aa3_73948886 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_167444842460e031c3242713_57661266', 'userlist');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "main.tpl.html");
}
/* {block 'userlist'} */
class Block_167444842460e031c3242713_57661266 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'userlist' => 
  array (
    0 => 'Block_167444842460e031c3242713_57661266',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


 <p >witaj użytkowniku <?php echo $_smarty_tpl->tpl_vars['user']->value->login;?>
 </p>
  Twój status <?php echo $_smarty_tpl->tpl_vars['user']->value->role;?>

<br><br>

	<a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
logout" class="pure-menu-heading pure-menu-link">Wyloguj</a>
 
    <a class="pure-menu-heading pure-menu-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
FishList">Powrót</a>


<table id="tab_people" class="pure-table pure-table-bordered">
<thead>
	<tr>
        <th>ID</th>
		<th>login</th>
		<th>Imie </th>
		<th>Nazwisko </th>
        <th>pesel </th>
		<th> data Modyfiakcji </th>
        <th> kto modyfikował </th>
        <th> Nazwa Roli </th>
	</tr>
</thead>
<tbody>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['uzytkownicy']->value, 'p');
$_smarty_tpl->tpl_vars['p']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->do_else = false;
?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['p']->value["ID"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["login"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["imie"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["nazwisko"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["pesel"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["data_Modyfiakcji"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["kto_modyfikowal"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['p']->value["Nazwa_Roli"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "admin") {?><td><a class="button-small pure-button button-secondary" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
UserEdit/<?php echo $_smarty_tpl->tpl_vars['p']->value['ID'];?>
">Edytuj</a>&nbsp;<a class="button-small pure-button button-warning" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
UserDelete/<?php echo $_smarty_tpl->tpl_vars['p']->value['ID'];?>
">Usuń</a></td><?php }?></tr>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    <thead>
	<tr>
        <th> id_sprzetu</th>
		<th> Nazwa Sprzetu</th>
		<th> Cena </th>
		<th> Rodzaj </th>
        <th> Kto Wynajmuje</th>
	</tr>
</thead>
</tbody>
</table>

<table id="tab_eq" class="pure-table pure-table-bordered">

<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sprzet']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
    <?php if ($_smarty_tpl->tpl_vars['r']->value["uzytkownicy_ID"] > 0) {?>
<tr><td><?php echo $_smarty_tpl->tpl_vars['r']->value["id_sprzetu"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["morenka"];?>
</td><?php if ($_smarty_tpl->tpl_vars['user']->value->role == "staly") {?><td><?php echo $_smarty_tpl->tpl_vars['r']->value["cena"]-$_smarty_tpl->tpl_vars['p']->value["cena"]*0.20;?>
</td><?php }
if ($_smarty_tpl->tpl_vars['user']->value->role == "uzytkownik") {?><td><?php echo $_smarty_tpl->tpl_vars['r']->value["cena"];?>
</td><?php }?><td><?php echo $_smarty_tpl->tpl_vars['r']->value["nazwa"];?>
</td><td><?php echo $_smarty_tpl->tpl_vars['r']->value["uzytkownicy_ID"];?>
</td><td><a onclick="confirmLink('<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
AdminRemove/<?php echo $_smarty_tpl->tpl_vars['r']->value['id_sprzetu'];?>
/<?php echo $_smarty_tpl->tpl_vars['r']->value['cena']-$_smarty_tpl->tpl_vars['r']->value['cena']*0.20;?>
','Czy na pewno ten klient zwrócił? Po oddaniu nie będzie możliwości zmiany')" class="button-small pure-button button-secondary">Klient wzrócił</a>&nbsp;</td></tr>
    <?php }
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</table>
<?php
}
}
/* {/block 'userlist'} */
}
