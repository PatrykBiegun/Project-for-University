<?php
/* Smarty version 3.1.34-dev-7, created on 2021-07-03 11:45:08
  from 'C:\xampp\htdocs\projekt\app\views\main.tpl.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_60e031a4e86c14_61592623',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '897248b76701007eb2c466b51ac9828c165c3bca' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projekt\\app\\views\\main.tpl.html',
      1 => 1625305206,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60e031a4e86c14_61592623 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Łowisko Ryb Skierniewicach">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Zaloguj się</title>
    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/js/functions.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/nicepage.css" media="screen">
    <link rel="icon" type="image/png" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/images/fisher.webp"/>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/Zaloguj.css" media="screen">
    <?php echo '<script'; ?>
 class="u-script" type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/jquery.js" defer=""><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 class="u-script" type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/nicepage.js" defer=""><?php echo '</script'; ?>
>
    <meta name="generator" content="Nicepage 3.17.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link rel="stylesheet" href="https://unpkg.com/purecss@2.0.6/build/pure-min.css" integrity="sha384-Uu6IeWbM+gzNVXJcM9XV3SohHtmWE+3VGi496jvgX1jyvDTXfdK+rfZc8C1Aehk5" crossorigin="anonymous">
    
    <?php echo '<script'; ?>
 type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"logo": "images/images.png"
}<?php echo '</script'; ?>
>
    <meta property="og:title" content="Zaloguj się">
    <meta property="og:type" content="website">
    <meta name="theme-color" content="#478ac9">
  </head>
  <body class="u-body"><header class="u-clearfix u-header u-header" id="sec-959f"><div class="u-clearfix u-sheet u-sheet-1">
        <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/Strona-Główna.html" class="u-align-left u-image u-logo u-image-1" data-image-width="251" data-image-height="201">
          <img src="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/images/images.png" class="u-logo-image u-logo-image-1" data-image-width="112.2519">
        </a>
        <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px;">
            <a class="u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#">
              <svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol id="menu-hamburger" viewBox="0 0 16 16" style="width: 16px; height: 16px;"><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</symbol>  
</defs></svg>
            </a>
          </div>
          <div class="u-custom-menu u-nav-container">
            <ul class="u-nav u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/Strona-Główna.html" style="padding: 10px 20px;">Strona Główna</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/O-nas.html" style="padding: 10px 20px;">O nas</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/Zaloguj-się.html" style="padding: 10px 20px;">Zaloguj się</a>
</li></ul>
          </div>
          <div class="u-custom-menu u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/Strona-Główna.html" style="padding: 10px 20px;">Strona Główna</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/O-nas.html" style="padding: 10px 20px;">O nas</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/Zaloguj-się.html" style="padding: 10px 20px;">Zaloguj się</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
        <h1 class="u-text u-text-1">Łowisko Ryb w Skierniewicach</h1>
      </div></header>

    	
<div class="kontent">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_84515412560e031a4e5f339_70864527', 'content');
?>

</div>   
    <div class="kontent">
    <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
        <ul>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
            <li><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </ul>
    <?php }?>
      </div>
	<div class="kontent">

 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_90548675960e031a4e7fbe4_92748171', 'top');
?>

        </div>   

    <div class="kontent">

 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_171903894160e031a4e80e30_50210384', 'bottom');
?>

        </div>   

    <div class="bigtable">

 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_77177820660e031a4e81e33_52223113', 'userSearch');
?>

        </div>   

    <div class="kontent">

 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_213406433460e031a4e82dd9_94743679', 'userlist');
?>
  
    </div>   


    

   
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-65ea"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">Wykonał Patryk Biegun&nbsp;</p>
      </div></footer>
    <section class="u-backlink u-clearfix u-grey-80">
      <a class="u-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/https://nicepage.com/website-templates" target="_blank">
        <span>Website Templates</span>
      </a>
      <p class="u-text">
        <span>created with</span>
      </p>
      <a class="u-link" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/css/https://nicepage.com/" target="_blank">
        <span>Website Builder Software</span>
      </a>. 
    </section>
  </body>
</html><?php }
/* {block 'content'} */
class Block_84515412560e031a4e5f339_70864527 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_84515412560e031a4e5f339_70864527',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
    <?php
}
}
/* {/block 'content'} */
/* {block 'top'} */
class Block_90548675960e031a4e7fbe4_92748171 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'top' => 
  array (
    0 => 'Block_90548675960e031a4e7fbe4_92748171',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 
 <?php
}
}
/* {/block 'top'} */
/* {block 'bottom'} */
class Block_171903894160e031a4e80e30_50210384 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'bottom' => 
  array (
    0 => 'Block_171903894160e031a4e80e30_50210384',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

 <?php
}
}
/* {/block 'bottom'} */
/* {block 'userSearch'} */
class Block_77177820660e031a4e81e33_52223113 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'userSearch' => 
  array (
    0 => 'Block_77177820660e031a4e81e33_52223113',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 
 <?php
}
}
/* {/block 'userSearch'} */
/* {block 'userlist'} */
class Block_213406433460e031a4e82dd9_94743679 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'userlist' => 
  array (
    0 => 'Block_213406433460e031a4e82dd9_94743679',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

 <?php
}
}
/* {/block 'userlist'} */
}
