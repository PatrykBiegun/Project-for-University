<?php
require_once '../init.php';
use core\App;
include App::getConf()->root_path.App::getConf()->action_script;

if(isset($_SESSION['user'])){
            $user = unserialize($_SESSION['user']); 
        }else{
            $user = false;
        }
        App::getSmarty()->assign("user",$user); 