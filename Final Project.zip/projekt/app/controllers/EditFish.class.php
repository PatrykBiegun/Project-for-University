<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\FishEditForm;

class EditFish {

    private $form; 

    public function __construct() {
        $this->form = new FishEditForm();
    }

    public function validateSave() {
        $this->form->ID_Ryby = ParamUtils::getFromRequest('ID_Ryby', true, 'Błędne wywołanie aplikacji');
        $this->form->Nazwa_ryby = ParamUtils::getFromRequest('Nazwa_ryby', true, 'Błędne wywołanie aplikacji');
        $this->form->nr_stawu = ParamUtils::getFromRequest('nr_stawu', true, 'Błędne wywołanie aplikacji');
        $this->form->cena_za_kilogram = ParamUtils::getFromRequest('cena_za_kilogram', true, 'Błędne wywołanie aplikacji');
        if (App::getMessages()->isError())
            return false;

        if (empty(trim($this->form->Nazwa_ryby))) {
            Utils::addErrorMessage('Wprowadź nazwę ryby');
        }
        if (empty(trim($this->form->nr_stawu))) {
            Utils::addErrorMessage('Wprowadź numer stawu');
        }
        if (empty(trim($this->form->cena_za_kilogram))) {
            Utils::addErrorMessage('Wprowadź cenę za kilogram');
        }

        if (App::getMessages()->isError())
            return false;

        return !App::getMessages()->isError();
    }

    public function validateEdit() {
        $this->form->ID_Ryby = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        return !App::getMessages()->isError();
    }

    public function action_FishNew() {
        $this->generateView();
    }

    //wysiweltenie rekordu do edycji wskazanego parametrem 'id'
    public function action_FishEdit() {
        // 1. walidacja id osoby do edycji
        if ($this->validateEdit()) {
            try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
                $record = App::getDB()->get("ryby", "*", [
                    "ID_Ryby" => $this->form->ID_Ryby
                ]);
                // 2.1 jeśli osoba istnieje to wpisz dane do obiektu formularza
                $this->form->ID_Ryby = $record['ID_Ryby'];
                $this->form->Nazwa_ryby = $record['Nazwa_ryby'];
                $this->form->nr_stawu = $record['nr_stawu'];
                $this->form->cena_za_kilogram = $record['cena_za_kilogram'];
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu/ to ID NIE ISTNIEJE :O');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        $this->generateView();
    }

    public function action_FishDelete() {
        if ($this->validateEdit()) {

            try {
                // 2. usunięcie rekordu
                App::getDB()->delete("ryby", [
                    "ID_Ryby" => $this->form->ID_Ryby
                ]);
                Utils::addInfoMessage('Pomyślnie usunięto Rybke');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        App::getRouter()->forwardTo('FishList');
    }

    public function action_FishSave() {

      
        if ($this->validateSave()) {
            try {

                //2.1 Nowy rekord
                if ($this->form->ID_Ryby == '') {
                    //sprawdź liczebność rekordów - nie pozwalaj przekroczyć 20
                    $count = App::getDB()->count("ryby");
                    if ($count <= 500) {
                        App::getDB()->insert("ryby", [
                            "Nazwa_ryby" => $this->form->Nazwa_ryby,
                            "nr_stawu" => $this->form->nr_stawu,
                            "cena_za_kilogram" => $this->form->cena_za_kilogram
                        ]);
                    } else { //za dużo rekordów
                        // Gdy za dużo rekordów to pozostań na stronie
                        Utils::addInfoMessage('Ograniczenie: Zbyt dużo rekordów. Aby dodać nowy usuń wybrany wpis.');
                        $this->generateView(); //pozostań na stronie edycji
                        exit(); //zakończ przetwarzanie, aby nie dodać wiadomości o pomyślnym zapisie danych
                    }
                } else {
                    App::getDB()->update("ryby", [
                        "Nazwa_ryby" => $this->form->Nazwa_ryby,
                        "nr_stawu" => $this->form->nr_stawu,
                        "cena_za_kilogram" => $this->form->cena_za_kilogram
                            ], [
                        "ID_Ryby" => $this->form->ID_Ryby
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu :O');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }

            // 3b. Po zapisie przejdź na stronę listy osób (w ramach tego samego żądania http)
            App::getRouter()->forwardTo('FishList');
        } else {
            // 3c. Gdy błąd walidacji to pozostań na stronie
            $this->generateView();
        }
    }

    public function generateView() {
        App::getSmarty()->assign('form', $this->form); // dane formularza dla widoku
        App::getSmarty()->display('FishEdit.tpl');
    }

}
