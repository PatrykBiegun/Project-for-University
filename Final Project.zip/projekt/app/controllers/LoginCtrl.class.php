<?php
namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\RoleUtils;
use app\forms\LoginForm;
use app\transfer\UserTransfer;

class LoginCtrl{
    
    private $form;
    private $account;
    private $role;
    private $idlog; 
    
    public function __construct(){
        $this->form = new LoginForm();
    }
    public function validate(){
        $this->form->login = ParamUtils::getFromRequest('login');
        $this -> form -> pass = base64_encode(ParamUtils::getFromRequest('pass'));  
        
         if (!isset($this->form->login))
            return false;

        if (empty($this->form->login)) {
            Utils::addErrorMessage('Nie podano loginu');
        }
        
        if (empty($this->form->pass)) {
            Utils::addErrorMessage('Nie podano hasła');
        }

        if (App::getMessages()->isError())
            return false;
        try{
            $this->account=App::getDB()->get("uzytkownicy", "ID", [
                    "login"=>$this->form->login,
                    "haslo"=>$this->form->pass
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('serwer nie działa ');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        }
        if(!isset($this->account) )
        {
          Utils::addErrorMessage('Konto nie istnieje / błędne dane logowania');  
            return false;
        }
        
        
         try{
            $this->idlog=App::getDB()->get("uzytkownicy_has_role", "role_Id_Roli", [
                    "uzytkownicy_ID"=>$this->account
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('to konto nie ma roli');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        }
        
        if(!isset($this->idlog))
        {
              Utils::addErrorMessage('to konto nie ma przypisanej roli');  
            return false;
        }
        
           try{
            $this->role=App::getDB()->get("role", "Nazwa_Roli", [
                    "Id_Roli"=>$this->idlog
                   
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage("Serwer nie odpowiada");
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        }
        
         if (App::getMessages()->isError())
            return false;
        
        $user = new UserTransfer($this -> account, $this->form->login, $this->role);
        $_SESSION['user']=serialize($user);
        
        RoleUtils::addRole($this->role);   
        
        return !App::getMessages()->isError();
}
    
    public function action_logowanie(){
        if($this->validate()){
              App::getRouter()->redirectTo('FishList');
        }
        else $this->generateView();
        
    }
    
    public function action_logout(){
        session_destroy();
         App::getRouter()->redirectTo('hello');
    }
  
    public function generateView(){
        App::getSmarty()->display('LoginView.tpl');
        
        
    }
}
