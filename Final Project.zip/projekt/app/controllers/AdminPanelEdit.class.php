<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\AdminPanelEditForm;
use app\transfer\UserTransfer;


class AdminPanelEdit {

    private $form; 
    private $user;

    public function __construct() {
        $this->form = new AdminPanelEditForm();
    }

    public function validateSave() {
        $this->form->ID = ParamUtils::getFromRequest('ID', true, 'Błędne wywołanie aplikacji');
        $this->form->login = ParamUtils::getFromRequest('login', true, 'Błędne wywołanie aplikacji');
        $this->form->imie = ParamUtils::getFromRequest('imie', true, 'Błędne wywołanie aplikacji');
        $this->form->nazwisko = ParamUtils::getFromRequest('nazwisko', true, 'Błędne wywołanie aplikacji');
        $this->form->idroli = ParamUtils::getFromRequest('idroli', true, 'Błędne wywołanie aplikacji');
        $this->user = unserialize($_SESSION['user']);
        
        if (App::getMessages()->isError())
            return false;

        if (empty(trim($this->form->login))) {
            Utils::addErrorMessage('Wprowadź login');
        }
        if (empty(trim($this->form->imie))) {
            Utils::addErrorMessage('Wprowadź Imie');
        }
        if (empty(trim($this->form->nazwisko))) {
            Utils::addErrorMessage('Wprowadź Nazwisko');
        }
        
        
        if (App::getMessages()->isError())
            return false;

        return !App::getMessages()->isError();
    }

    public function validateEdit() {
        $this->form->ID = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        return !App::getMessages()->isError();
    }

    //wysiweltenie rekordu do edycji wskazanego parametrem 'id'
    
    public function action_UserEdit() {
        // 1. walidacja id osoby do edycji
        if ($this->validateEdit()) {
            try {
                // 2. odczyt z bazy danych osoby o podanym ID (tylko jednego rekordu)
                $record = App::getDB()->get("uzytkownicy", "*", [
                    "ID" => $this->form->ID
                ]);
                $this->form->ID = $record['ID'];
                $this->form->imie = $record['imie'];
                $this->form->nazwisko = $record['nazwisko'];
                $this->form->login = $record['login'];
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas odczytu rekordu/ to ID NIE ISTNIEJE :O');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        $this->generateView();
    }

    public function action_UserDelete() {
        if ($this->validateEdit()) {

            try {
                // 2. usunięcie rekordu
                 App::getDB()->delete("uzytkownicy_has_role", [
                    "uzytkownicy_ID" => $this->form->ID
                ]);
                
               
                Utils::addInfoMessage('Pomyślnie usunięto Uzytkownika');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
            
          try {  
             App::getDB()->update("sprzet", [
                    "uzytkownicy_ID" => NULL 
                ],[
               "uzytkownicy_ID" =>$this->form->ID
             ]);
                
               
                Utils::addInfoMessage('');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }   
            
            
    
            
            
            try {
                  App::getDB()->delete("uzytkownicy", [
                    "ID" => $this->form->ID
                     
               ]);
                Utils::addInfoMessage('Pomyślnie usunięto Uzytkownika');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił błąd podczas usuwania rekordu');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }
        }

        App::getRouter()->forwardTo('AdminPanelGo');
    }

    public function action_UserSave() {

      
        if ($this->validateSave()) {
            try {

                //2.1 Nowy rekord
                if ($this->form->ID == '') {
                    //sprawdź liczebność rekordów - nie pozwalaj przekroczyć 20
                    $count = App::getDB()->count("uzytkownicy");
                    if ($count <= 50) {
                        App::getDB()->insert("uztkownicy", [
                            "login" => $this->form->login,
                            "imie" => $this->form->imie,
                            "nazwisko" => $this->form->nazwisko
                        ]);
                    } else { //za dużo rekordów
                        // Gdy za dużo rekordów to pozostań na stronie
                        Utils::addInfoMessage('Ograniczenie: Zbyt dużo rekordów. Aby dodać nowy usuń wybrany wpis.');
                        $this->generateView(); //pozostań na stronie edycji
                        exit(); //zakończ przetwarzanie, aby nie dodać wiadomości o pomyślnym zapisie danych
                    }
                } else {
                     App::getDB()->update("uzytkownicy_has_role", [
                         "role_Id_Roli" => $this->form->idroli,
                            ], [
                        "uzytkownicy_ID" => $this->form->ID
                    ]);
                    
                    App::getDB()->update("uzytkownicy", [
                         "login" => $this->form->login,
                         "imie" => $this->form->imie,
                         "nazwisko" => $this->form->nazwisko,
                         "kto_modyfikowal" => $this->user->id
                            ], [
                        "ID" => $this->form->ID
                    ]);
                }
                Utils::addInfoMessage('Pomyślnie zapisano rekord');
            } catch (\PDOException $e) {
                Utils::addErrorMessage('Wystąpił nieoczekiwany błąd podczas zapisu rekordu :O');
                if (App::getConf()->debug)
                    Utils::addErrorMessage($e->getMessage());
            }

            // 3b. Po zapisie przejdź na stronę listy osób (w ramach tego samego żądania http)
      App::getRouter()->redirectTo('AdminPanelGo');
        } else {
            // 3c. Gdy błąd walidacji to pozostań na stronie
            $this->generateView();
        }
    }

    public function generateView() {
        App::getSmarty()->assign('form', $this->form); // dane formularza dla widoku
        App::getSmarty()->display('AdminEdit.tpl');
    }

}
