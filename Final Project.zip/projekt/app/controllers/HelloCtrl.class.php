<?php

namespace app\controllers;



use core\App;
use core\Message;
use core\Utils;


include 'LoginCtrl.class.php';



class HelloCtrl {
    private $user;
    
    public function action_hello() {
    $this -> user = unserialize($_SESSION['user']);
        
        
        App::getMessages()->addMessage(new Message("Ups twoja sesja wygasła", Message::INFO));
        Utils::addInfoMessage("Proszę zalogować się ponownie");
        
        App::getSmarty()->assign("user",$this -> user);        
        App::getSmarty()->display("Hello.tpl");

    }
    
}
