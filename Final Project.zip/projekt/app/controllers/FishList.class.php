<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use app\forms\FishSearchForm;
use app\transfer\UserTransfer;
use app\forms\PageForm;

class FishList {

    private $form; 
    private $records;
    private $page;
    private $items;
    public function __construct() {
        $this->form = new FishSearchForm();
         $this->page = new PageForm();

    }

    public function validate() {
        $this->form->fishname = ParamUtils::getFromRequest('fishname');

        return !App::getMessages()->isError();
    }

    public function action_FishList() {
        $this->validate();

        $this -> page -> page = ParamUtils::getFromCleanURL(1);

        
         $this -> page -> size = 3;

        $search_params = []; 
        if (isset($this->form->fishname) && strlen($this->form->fishname) > 0) {
            $search_params['Nazwa_ryby[~]'] = $this->form->fishname . '%';
           $this -> page -> size = 20;
        }

        $num_params = sizeof($search_params);
        if ($num_params > 1) {
            $where = ["AND" => &$search_params];
        } else {
            $where = &$search_params;
        } 
        $where ["ORDER"] = "Nazwa_ryby";

       
        $this -> items = App::getDB() -> count("ryby", "ID_Ryby");

        $this -> page -> total = ceil($this -> items/$this -> page -> size);

        if($this -> page -> page < 1) {
            $this -> page -> page = 1;
        }

        if($this -> page -> page > $this -> page -> total) {
            $this -> page -> page = $this -> page -> total;
        }

        $this -> page -> offset = $this -> page -> size * ($this -> page -> page - 1);

        if($this -> page -> offset < 0) {
            $this -> page -> offset = 0;
        }
        $where ["LIMIT"] = [$this -> page -> offset, $this -> page -> size];
        
        try {
            $this->records = App::getDB()->select("ryby", [
                "ID_Ryby",
                "Nazwa_ryby",
                "nr_stawu",
                "cena_za_kilogram",
                    ], $where);
        } catch (   \PDOException $e) {
            Utils::addErrorMessage('rybuw brakuje');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }

       if(isset($_SESSION['user'])){
            $user = unserialize($_SESSION['user']); 
        }else{
            $user = false;
        }
        
        App::getSmarty()->assign("user",$user); 
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->assign('ryby', $this->records);  
        App::getSmarty() -> assign('page', $this -> page);
        App::getSmarty()->display('FishList.tpl');
    }

}
