<?php
namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\RoleUtils;
use app\forms\AdminPanelForm;
use app\forms\EquipmentForm;

class AdminPanel {

    private $form; 
    private $records;
    private $sprzecior;
    private $suma;
    private $user;

     
    public function __construct() {
        $this->form = new AdminPanelForm();
    }



    public function validate() {
        
        $this->form->login = ParamUtils::getFromRequest('login');
        
          $this->user = unserialize($_SESSION['user']);
        

          try{
            $this->suma=App::getDB()->get("uzytkownicy", "suma", [
                    "ID"=>$this->user->id,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('błąd sumy');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        } 
        
        $search_params = []; 
        if (isset($this->form->login) && strlen($this->form->login) > 0) {
            $search_params['Login[~]'] = $this->form->login . '%';
        }

        $num_params = sizeof($search_params);
        if ($num_params > 1) {
            $where = ["AND" => &$search_params];
        } else {
            $where = &$search_params;
        } 
        $where ["ORDER"] = "ID";
        
        
        
        try {
            $this->records = App::getDB()->select("uzytkownicy", [
                "[>]uzytkownicy_has_role" => ["ID" => "uzytkownicy_ID"],
                "[>]role" => ["uzytkownicy_has_role.role_Id_Roli" => "Id_Roli"]
                ],[
                "uzytkownicy.ID",
                "uzytkownicy.login",
                "uzytkownicy.imie",
                "uzytkownicy.nazwisko",
                "uzytkownicy.pesel",
                "uzytkownicy.kto_modyfikowal",
                "uzytkownicy.data_Modyfiakcji",
                "uzytkownicy.kto_stworzyl",
                "role.Nazwa_Roli"
                    ], $where);
        } catch (   \PDOException $e) {
            Utils::addErrorMessage('baza użytkowników jest pusta');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }

       if(isset($_SESSION['user'])){
            $user = unserialize($_SESSION['user']); 
        }else{
            $user = false;
        }
        
           $search_params = []; 
        if (isset($this->form->nazwa) && strlen($this->form->nazwa) > 0) {
            $search_params['nazwa[~]'] = $this->form->nazwa . '%';

        }

        $num_params = sizeof($search_params);
        if ($num_params > 1) {
            $where = ["AND" => &$search_params];
        } else {
            $where = &$search_params;
        } 
        $where ["ORDER"] = "sprzet.id_sprzetu";
  
        try {
            $this->sprzecior = App::getDB()->select("sprzet", [
                "[>]uzytkownicy" => ["uzytkownicy_ID" => "ID"],
                "[>]kategorie" => ["kategorie_ID_Kategorii" => "ID_Kategorii"]
                ],[
                "uzytkownicy.ID",
                "uzytkownicy.suma",
                "sprzet.id_sprzetu ",
                "sprzet.morenka",
                "sprzet.cena",
                "sprzet.uzytkownicy_ID",
                "kategorie.ID_Kategorii",
                "kategorie.nazwa",
                "kategorie.opis",
                    ], $where);
        } catch (   \PDOException $e) {
            Utils::addErrorMessage('baza sprzetów jest pusta ');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }

       if(isset($_SESSION['user'])){
            $user = unserialize($_SESSION['user']); 
        }else{
            $user = false;
        }
        
        App::getSmarty()->assign("user",$user); 
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->assign('sprzet', $this->sprzecior); 
        App::getSmarty()->assign('suma', $this->suma); 
        App::getSmarty()->assign('uzytkownicy', $this->records);  
    }

         public function action_AdminPanelGo(){
         $this->validate();
              $this->generateView();
         }
    
    public function generateView(){
         
        App::getSmarty()->assign('uzytkownicy', $this->records);  
        App::getSmarty()->display('AdminView.tpl');   }
    
     public function action_AdminRemove(){
         $this->validate();
            
         
         
              try{
            $this->suma=App::getDB()->get("uzytkownicy", "suma", [
                    "ID"=>$this->user->id,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('błąd sumy');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        } 
         
        $this->form->id_sprzetu  = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        $this->form->cena = ParamUtils::getFromCleanURL(2, true, 'Błędne wywołanie aplikacji xd');

         
         
         App::getDB()->update("uzytkownicy", [
                        "suma" => $this->suma
                        
                            ], [
                        "ID" => $this->user->id
                    ]);
         
         App::getDB()->update("sprzet", [
                        "uzytkownicy_ID" => NULL
                        
                            ], [
                        "id_sprzetu" => $this->form->id_sprzetu
                    ]);
         
         
         $this->validate();
         
         if($this->suma<300){
             App::getDB()->update("uzytkownicy_has_role", [
                        "role_Id_Roli" => 2
                        
                            ], [
                        "uzytkownicy_ID" =>  $this->user->id
                    ]);
         }
         
         
         
         $this->suma=0;
         
        $this->generateView();
    }

}
        



