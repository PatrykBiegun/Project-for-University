<?php
namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\RoleUtils;
use app\forms\EquipmentForm;



class Equipment{
  
    private $suma;
    private $form; 
    private $records;
    private $user;
  
    
    public function __construct() {
        $this->form = new EquipmentForm();
    }
    
   


    public function validate() {
        
        $this->suma=0;

        $this->form->nazwa = ParamUtils::getFromRequest('nazwa');
        
        $this->user = unserialize($_SESSION['user']);
        

          try{
            $this->suma=App::getDB()->get("uzytkownicy", "suma", [
                    "ID"=>$this->user->id,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('błąd sumy');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        } 
        
        
      
        $search_params = []; 
        if (isset($this->form->nazwa) && strlen($this->form->nazwa) > 0) {
            $search_params['nazwa[~]'] = $this->form->nazwa . '%';

        }

        $num_params = sizeof($search_params);
        if ($num_params > 1) {
            $where = ["AND" => &$search_params];
        } else {
            $where = &$search_params;
        } 
        $where ["ORDER"] = "sprzet.id_sprzetu";
         
        
        try {
            $this->records = App::getDB()->select("sprzet", [
                "[>]uzytkownicy" => ["uzytkownicy_ID" => "ID"],
                "[>]kategorie" => ["kategorie_ID_Kategorii" => "ID_Kategorii"]
                ],[
                "uzytkownicy.ID",
                "uzytkownicy.suma",
                "sprzet.id_sprzetu ",
                "sprzet.morenka",
                "sprzet.cena",
                "sprzet.uzytkownicy_ID",
                "kategorie.ID_Kategorii",
                "kategorie.nazwa",
                "kategorie.opis",
                    ], $where);
        } catch (   \PDOException $e) {
            Utils::addErrorMessage('baza sprzetów jest pusta ');
            if (App::getConf()->debug)
                Utils::addErrorMessage($e->getMessage());
        }

       if(isset($_SESSION['user'])){
            $user = unserialize($_SESSION['user']); 
        }else{
            $user = false;
        }
        
        
        
        App::getSmarty()->assign("user",$user); 
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->assign('sprzet', $this->records); 
        App::getSmarty()->assign('suma', $this->suma); 
     

    }

         public function action_Equipment(){
         $this->validate();
              $this->generateView();
         }
    
    public function generateView(){
         
        App::getSmarty()->assign('uzytkownicy', $this->records);  
        App::getSmarty()->display('EquipmentView.tpl');   
        
        }
        
  public function action_EquipmentSorted(){
        
        $this->validate();

        App::getSmarty()->assign('uzytkownicy', $this->records);  
        App::getSmarty()->display('table.tpl');   
        
        }
    
     public function action_EquipmentRent(){
         $this->validate();
                     $this->suma=0;

         
         
              try{
            $this->suma=App::getDB()->get("uzytkownicy", "suma", [
                    "ID"=>$this->user->id,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('błąd sumy');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        } 
         
        $this->form->id_sprzetu  = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        $this->form->cena = ParamUtils::getFromCleanURL(2, true, 'Błędne wywołanie aplikacji xd');

         
         $this->suma = $this->suma + $this->form->cena;
         
         App::getDB()->update("uzytkownicy", [
                        "suma" => $this->suma
                        
                            ], [
                        "ID" => $this->user->id
                    ]);
         
         App::getDB()->update("sprzet", [
                        "uzytkownicy_ID" => $this->user->id
                        
                            ], [
                        "id_sprzetu" => $this->form->id_sprzetu
                    ]);
         
         
         $this->validate();
         
         if($this->user->role != 'admin'){
         if($this->suma>300){
             App::getDB()->update("uzytkownicy_has_role", [
                        "role_Id_Roli" => 3
                        
                            ], [
                        "uzytkownicy_ID" =>  $this->user->id
                    ]);
         }}
         
         
         
         $this->suma=0;
         
            header("Location:" . $conf->app_url . "/projekt/public/Equipment");
    }
         
    public function action_EquipmentBack(){
         $this->validate();
            
         
              try{
            $this->suma=App::getDB()->get("uzytkownicy", "suma", [
                    "ID"=>$this->user->id,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('błąd sumy');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        } 
         
        $this->form->id_sprzetu  = ParamUtils::getFromCleanURL(1, true, 'Błędne wywołanie aplikacji');
        $this->form->cena = ParamUtils::getFromCleanURL(2, true, 'Błędne wywołanie aplikacji xd');

         
         $this->suma = $this->suma - $this->form->cena;
         
        
         App::getDB()->update("uzytkownicy", [
                        "suma" => $this->suma
                        
                            ], [
                        "ID" => $this->user->id
                    ]);
         
         App::getDB()->update("sprzet", [
                        "uzytkownicy_ID" => NULL
                        
                            ], [
                        "id_sprzetu" => $this->form->id_sprzetu
                    ]);
         
         
         $this->validate();
         
         if($this->user->role != 'admin'){
         if($this->suma<300){
             App::getDB()->update("uzytkownicy_has_role", [
                        "role_Id_Roli" => 2
                        
                            ], [
                        "uzytkownicy_ID" =>  $this->user->id
                    ]);
         }}
         
         
         
         $this->suma=0;

      
            header("Location:" . $conf->app_url . "/projekt/public/Equipment");

    }

}
    


                   
