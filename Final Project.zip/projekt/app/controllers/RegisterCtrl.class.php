<?php
namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\RoleUtils;
use app\forms\RegisterForm;

class RegisterCtrl{
  
    
    private $form;
    private $account;
    
    private $idlog; 
    
    public function __construct(){
        $this->form = new RegisterForm();
    }
    
    public function validate(){
        $this->form->login = ParamUtils::getFromRequest('login');
        $this -> form -> pass = base64_encode(ParamUtils::getFromRequest('pass'));
        $this->form->name = ParamUtils::getFromRequest('name');
        $this->form->surname = ParamUtils::getFromRequest('surname');   
        $this->form->pesel = ParamUtils::getFromRequest('pesel');
       
        
        
       
        if (empty($this->form->login)) {
            Utils::addErrorMessage('Nie podano loginu');
        }
        
        if (empty($this->form->pass)) {
            Utils::addErrorMessage('Nie podano hasła');
        }
        
        if (empty($this->form->name)) {
            Utils::addErrorMessage('Nie podano imienia');
        }
        
        if (empty($this->form->surname)) {
            Utils::addErrorMessage('Nie podano nazwiska');
        }
        
        if (empty($this->form->pesel)) {
            Utils::addErrorMessage('Nie podano peselu');  
        } 


        
        if (App::getMessages()->isError())
        {return false;}
        
           if (!preg_match('/^[0-9]{11,}$/D', ($this->form->pesel))) {
            Utils::addErrorMessage('pesel ma sie składać z 11 cyfr');
        }
              
        if (App::getMessages()->isError())
             {return false;}
        
        try{
            $this->account=App::getDB()->get("uzytkownicy", "login", [
                    "login"=>$this->form->login,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('nie udało się stworzyć urzytkownika');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        }
       
        if(!empty($this->account) )
        {
          Utils::addErrorMessage('Użtykownik z taką nazwą już istnieje');  
            return false;
        }
        
        try{
            $this->account=App::getDB()->get("uzytkownicy", "pesel", [
                    "pesel"=>$this->form->pesel,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('nie udało się stworzyć urzytkownika');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        }
        
          if(!empty($this->account) )
        {
          Utils::addErrorMessage('Użtykownik z takim peselem już jest w naszej bazie');  
            return false;
        }
        
        App::getDB()->insert( "uzytkownicy", [
	"login" => $this->form -> login,
	"haslo" => $this->form -> pass,
	"imie" => $this->form -> name,
    "nazwisko" => $this->form -> surname,   
    "pesel" => $this->form -> pesel,
    "kto_stworzyl" =>  '1',    
]);
        
        try{
            $this->account=App::getDB()->get("uzytkownicy", "ID", [
                    "login"=>$this->form->login,
            ]);   
        }
       catch (\PDOException $e) {
            Utils::addErrorMessage('wyjebało w kosmos XD');
            if (App::getConf()->debug) {
                Utils::addErrorMessage($e->getMessage());
            }
        } 
        
        App::getDB()->insert( "uzytkownicy_has_role", [
  
        "uzytkownicy_ID" =>  $this->account,  
        "role_Id_Roli" =>  '2',      
]);
        
        return !App::getMessages()->isError();
}
    
    
     public function action_register(){
        if($this->validate()){
              App::getRouter()->redirectTo('logowanie');
        }
        else $this->generateView();
        
    }
    
         public function generateView(){
        App::getSmarty()->display('RegisterView.tpl');
        
        
    }
}
