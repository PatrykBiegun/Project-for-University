<?php

namespace app\forms;

class FishEditForm {
    public $ID_Ryby;
	public $Nazwa_ryby;
	public $nr_stawu;
    public $cena_za_kilogram;
}