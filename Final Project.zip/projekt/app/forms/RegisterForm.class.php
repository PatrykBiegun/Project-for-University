<?php

namespace app\forms;

class RegisterForm {
	public $login;
	public $pass;
    public $name;
	public $surname;
    public $pesel;
	
}