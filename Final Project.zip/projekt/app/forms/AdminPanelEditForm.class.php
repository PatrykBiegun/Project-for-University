<?php

namespace app\forms;

class AdminPanelEditForm {
    public $ID;
	public $login;
    public $imie;
	public $nazwisko;
    public $email;
    public $rola;
    public $idroli;
}