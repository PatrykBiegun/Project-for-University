<?php

namespace app\forms;

class EquipmentForm {
	public $id_sprzetu; 
	public $morenka;
    public $cena;
    public $uzytkownicy_ID; 
    public $kategorie_ID_Kategorii; 
    public $ID_Kategorii;
    public $nazwa;
    public $opis;
}