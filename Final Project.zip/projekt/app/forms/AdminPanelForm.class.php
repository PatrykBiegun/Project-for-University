<?php

namespace app\forms;

class AdminPanelForm {
    public $ID;
	public $login;
	public $pass;
    public $name;
	public $surname;
    public $pesel;
	
}