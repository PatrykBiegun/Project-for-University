<?php

namespace app\forms;

class PageForm{

    public $size;
    public $offset;
    public $page;
    public $total;
}