<?php

namespace app\forms;

class FishSearchForm {
	public $fishname;
	
	
}