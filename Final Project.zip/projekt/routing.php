<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('hello'); #default action
App::getRouter()->setLoginRoute('logowanie'); #action to forward if no permissions

Utils::addRoute('FishList', 'FishList');
Utils::addRoute('logowanie', 'LoginCtrl');
Utils::addRoute('register', 'RegisterCtrl');
Utils::addRoute('hello', 'HelloCtrl', ["admin", "uzytkownik", "staly"]);
Utils::addRoute('logout', 'LoginCtrl', ["admin", "uzytkownik", "staly"]);
Utils::addRoute('FishNew',     'EditFish',	['user','admin', "staly"]);
Utils::addRoute('AdminPanelGo',     'AdminPanel',	['user','admin', "staly"]);
Utils::addRoute('FishEdit',    'EditFish',	['uzytkownik','admin', "staly"]);
Utils::addRoute('FishSave',    'EditFish',	['uzytkownik','admin', "staly"]);
Utils::addRoute('FishDelete',  'EditFish',	['admin']);
Utils::addRoute('UserEdit',    'AdminPanelEdit',	['admin']);
Utils::addRoute('UserDelete',  'AdminPanelEdit',	['admin']);
Utils::addRoute('AdminPanelGo',   'AdminPanel',	['admin']);
Utils::addRoute('UserSave',   'AdminPanelEdit',	['admin']);
Utils::addRoute('Equipment',   'Equipment',	['uzytkownik','admin', "staly"]);
Utils::addRoute('EquipmentRent',   'Equipment',	['uzytkownik','admin', "staly"]);
Utils::addRoute('EquipmentSorted',   'Equipment',	['uzytkownik','admin', "staly"]);
Utils::addRoute('EquipmentBack',   'Equipment',	['uzytkownik','admin', "staly"]);
Utils::addRoute('AdminRemove',   'AdminPanel',	['uzytkownik','admin', "staly"]);


//Utils::addRoute('action_name', 'controller_class_name');EquipmentRent